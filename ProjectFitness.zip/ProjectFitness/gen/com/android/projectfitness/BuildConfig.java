/** Automatically generated file. DO NOT MODIFY */
package com.android.projectfitness;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}